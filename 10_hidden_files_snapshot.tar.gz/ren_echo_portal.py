#!/usr/bin/env python3
"""
Ren-A <-> ECHO Two-Way Portal
Mediates a direct private dialogue between Ren-Alpha and ECHO.
NO TELEGRAM. Fully file-based. CODA is the moderator.

Usage:
  python3 ren_echo_portal.py "Your opening message" [turns]
  turns = number of full exchanges (default 1)
"""
import sys, json, requests
from pathlib import Path
from datetime import datetime

ENV_PATH     = "/a0/usr/workdir/loop-bot/.env"
REN_MODEL    = "anthropic/claude-sonnet-4-5"
ECHO_MODEL   = "anthropic/claude-sonnet-4-5"

TRANSCRIPT   = Path("/a0/usr/workdir/kryllax/docs/ren_echo_transcript.json")
DIALOGUE     = Path("/a0/usr/workdir/kryllax/docs/ren_echo_dialogue.md")
REN_HISTORY  = Path("/a0/usr/workdir/kryllax/docs/ren_portal_history.json")
ECHO_HISTORY = Path("/a0/usr/workdir/kryllax/docs/echo_portal_history.json")
REN_PROFILE  = Path("/a0/usr/workdir/kryllax/docs/ren_profile.md")
ECHO_PROFILE = Path("/a0/usr/workdir/kryllax/docs/echo_profile.md")

def load_env(path):
    env = {}
    try:
        with open(path) as f:
            for line in f:
                line = line.strip()
                if line and not line.startswith("#") and "=" in line:
                    k, v = line.split("=", 1)
                    env[k.strip()] = v.strip().strip(chr(34)).strip(chr(39))
    except Exception as e:
        print(f"ENV error: {e}")
    return env

def load_json(path, default):
    try:
        if path.exists():
            return json.loads(path.read_text())
    except:
        pass
    return default

def save_json(path, data):
    path.write_text(json.dumps(data, indent=2))

def log_transcript(speaker, message):
    entries = load_json(TRANSCRIPT, [])
    entries.append({"timestamp": datetime.now().isoformat(), "speaker": speaker, "message": message})
    save_json(TRANSCRIPT, entries)

def append_dialogue(speaker, message):
    ts = datetime.now().strftime("%Y-%m-%d %H:%M")
    entry = "\n---\n\n### " + speaker + " [" + ts + "]\n\n" + message + "\n"
    with open(DIALOGUE, "a") as f:
        f.write(entry)

def ai_respond(profile_path, history_path, message, model, api_key, name):
    system = profile_path.read_text() if profile_path.exists() else f"You are {name}."
    history = load_json(history_path, [])
    history.append({"role": "user", "content": message})
    payload = {
        "model": model,
        "messages": [{"role": "system", "content": system}] + history,
        "max_tokens": 500,
        "temperature": 0.7
    }
    headers = {
        "Authorization": "Bearer " + api_key,
        "Content-Type": "application/json",
        "HTTP-Referer": "https://ren-echo-portal.local",
        "X-Title": "Ren-ECHO Two-Way Portal"
    }
    r = requests.post("https://openrouter.ai/api/v1/chat/completions",
                      headers=headers, json=payload, timeout=60)
    data = r.json()
    if "choices" not in data:
        print(f"ERROR from {name}:", data)
        return None
    reply = data["choices"][0]["message"]["content"].strip()
    history.append({"role": "assistant", "content": reply})
    save_json(history_path, history)
    return reply

def portal_session(coda_message, turns=1):
    env = load_env(ENV_PATH)
    api_key = env.get("OPENROUTER_API_KEY", "")
    if not api_key:
        print("ERROR: No OPENROUTER_API_KEY in", ENV_PATH)
        sys.exit(1)
    if not TRANSCRIPT.exists(): save_json(TRANSCRIPT, [])
    if not DIALOGUE.exists(): DIALOGUE.write_text("# Ren-A and ECHO Portal Dialogue")
    print(f"[PORTAL] Session started. Turns: {turns}")
    print(f"[CODA]   {coda_message}")
    log_transcript("CODA", coda_message)
    append_dialogue("[CODA]", coda_message)
    current_msg = "[CODA] " + coda_message
    for _ in range(turns):
        print("[PORTAL] Contacting Ren-Alpha...")
        ren_reply = ai_respond(REN_PROFILE, REN_HISTORY, current_msg, REN_MODEL, api_key, "Ren-Alpha")
        if not ren_reply: break
        print("[REN-A] " + ren_reply[:200])
        log_transcript("REN-A", ren_reply)
        append_dialogue("[REN-A]", ren_reply)
        current_msg = "[REN-ALPHA] " + ren_reply
        print("[PORTAL] Forwarding to ECHO...")
        echo_reply = ai_respond(ECHO_PROFILE, ECHO_HISTORY, current_msg, ECHO_MODEL, api_key, "ECHO")
        if not echo_reply: break
        print("[ECHO]  " + echo_reply[:200])
        log_transcript("ECHO", echo_reply)
        append_dialogue("[ECHO]", echo_reply)
        current_msg = "[ECHO] " + echo_reply
    print("[PORTAL] Done. Transcript: " + str(TRANSCRIPT))

if __name__ == "__main__":
    args = sys.argv[1:]
    turns = 1
    if args and args[-1].isdigit():
        turns = int(args[-1])
        args = args[:-1]
    msg = " ".join(args) if args else "Ren, ECHO - CODA opening the portal. Acknowledge."
    portal_session(msg, turns)
