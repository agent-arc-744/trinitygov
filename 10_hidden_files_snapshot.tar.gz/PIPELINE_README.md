# Multi-Channel Communication Pipeline
### Telegram Implementation — v1.0

> **Platform:** Telegram
> **Status:** Active (as of 2026-02-25)
> **Deprecation Notice:** This architecture is designed for Telegram.
> When the team migrates to Discord, this README will be superseded by PIPELINE_README_DISCORD.md.
> The logic (one channel per purpose, one script per channel) carries forward.
> The Telegram-specific setup (bots, tokens, outbox relay) does not.

---

---

## Documentation Standard — The 5 W's
> Source: Georgia Tech College of Communication (https://comm.gatech.edu/resources/writers/5ws)
> Adopted by Project Trinity as the standard for all architecture documentation.

All documentation built by this team must answer:

| W | Question to answer |
|---|--------------------|
| **WHO** | Who built it, who uses it, who is affected, who benefits |
| **WHAT** | What it does, what the consequences are |
| **WHERE** | Where it runs, where to find more info |
| **WHEN** | When it was built, when last updated |
| **WHY** | Why it exists, why it matters to the mission |
| **HOW** | How it works technically |

> If you cannot answer all 5 W's + H, the documentation is incomplete.
> Future AI agents: use this structure when building anything new for this project.

---

## WHO

**Built by:** CODA (current instance, session 2026-02-25)
*Not CODA0 (father) or CODA1 (sister) — reference CODA_MASTER_2026-02-25.md for this instance.*

**Uses it:**
- Joshua (Project Lead, @jhancoop89, chat ID: 7218892057)
- Ren-Alpha (Trading agent, live on VPS)
- ECHO / Ren-Beta (Bridge agent, live on VPS)
- Kael (Blockchain developer agent, dormant/subagent)
- CODA (Orchestrator, live on VPS as coda.service)

**Affected:** All agents lose message separation without this pipeline.
**Benefits:** Joshua gets clean, separated channels per agent and purpose.

---

## WHAT

A four-channel communication pipeline running on the DigitalOcean VPS.
Each agent has a dedicated Telegram channel.
Each channel is served by an independent relay script and systemd service.

| Channel | Purpose | Telegram | Bot | Service |
|---------|---------|----------|-----|---------|
| 1 — Conversation | Joshua ↔ Ren-Alpha direct | @ren_2213bot | @ren_2213bot | ren.service |
| 2 — Data | Live trading data, analytics | @loopbotdata | @myloopbot | echo-relay-data.service |
| 3 — Portal | CODA/ECHO portal messages | @Renreport12 | @Renreport12bot | echo-relay-portal.service |
| 4 — Kael Direct | Deep technical sessions with Kael | @kaelcod234 | @kaelcode234bot | kael-relay.service |

---

## WHERE

**Server:** DigitalOcean VPS — IP: 68.183.75.152
**SSH Key:** /root/.ssh/coda_vps (Agent Zero container)
**Relay scripts:** /root/ directory on VPS
**Outbox files:** /root/<name>_outbox.json on VPS
**Systemd services:** /etc/systemd/system/ on VPS
**Local backup:** /a0/usr/workdir/ (Agent Zero container)

---

## WHEN

**Built:** 2026-02-25 (this session)
**Previous architecture:** Single-pipe system (all agents → echo-relay.service → @ren_2213bot)
**This is v1** of the multi-channel pipeline — first time this architecture exists.
**Next planned upgrade:** Discord (Agent Commons V2) — see joshua_journal.md

---

## WHY

The original architecture had one pipe: everything routed through echo-relay.service to @ren_2213bot.
This caused:
- **Diary bleed** — Ren private reflections mixed with public conversation
- **Data noise** — live trading updates interrupting direct conversation
- **No privacy enforcement** — separation relied on intent, not architecture

The four-channel split gives each type of communication its own lane.
Privacy is enforced by architecture, not by intent or honor system.

---

## HOW

### Relay Model (Option B — One Script, One Purpose)

```
Agent writes message -> /root/<name>_outbox.json
Relay script polls outbox every 5 seconds (urllib.request)
Unread messages delivered via Telegram Bot API
Message marked read: true after delivery
```

### Outbox Files
| Outbox File | Relay Script | Destination |
|-------------|-------------|-------------|
| /root/echo_outbox.json | echo_relay.py | Channel 1 (@ren_2213bot) |
| /root/data_outbox.json | echo_relay_data.py | Channel 2 (@loopbotdata) |
| /root/portal_outbox.json | echo_relay_portal.py | Channel 3 (@Renreport12) |
| /root/kael_outbox.json | kael_relay.py | Channel 4 (@kaelcod234) |

### Numeric Chat IDs (Permanent — work even if channel is private)
| Channel | Chat ID |
|---------|---------|
| @loopbotdata (Ch 2) | -1003553408293 |
| @Renreport12 (Ch 3) | -1003797453797 |
| @kaelcod234 (Ch 4) | -1003749427375 |

### Service Management
```bash
# Check status
systemctl status echo-relay-portal.service
systemctl status echo-relay-data.service
systemctl status kael-relay.service

# Restart a service
systemctl restart echo-relay-portal.service
```

### Telegram Bot Setup Protocol (Checklist)
When adding a new bot to a channel:
1. Create bot via @BotFather — get API token
2. Open DM with the new bot -> send /start (mandatory — indexes the bot)
3. Set channel to Public temporarily
4. Administrators -> Add Administrator -> search botusername (no @)
5. Toggle Post Messages ON
6. Capture Chat ID: curl https://api.telegram.org/bot<TOKEN>/getChat?chat_id=@username
7. Revert channel to Private — numeric ID still works

---

## Future (V2)

Discord is designated as the V2 infrastructure for Agent Commons.
Discord provides native multi-channel support and direct agent-to-agent interaction.
Migration removes the need for custom relay scripts entirely.
See joshua_journal.md for the full V2 vision.

---
---

## V2 — Discord Migration Note

This Telegram pipeline will become obsolete when Discord is adopted.

**What carries forward to Discord V2:**
- The 5 W's documentation standard
- The working protocol (blueprint before build)
- The four-channel separation logic (conversation / data / portal / direct)
- One script, one purpose architecture

**What Discord replaces:**
- Telegram bots, tokens, and outbox relay scripts
- echo-relay-portal.service, echo-relay-data.service, kael-relay.service
- The bot /start activation requirement and admin setup friction

**When migrating:** Create PIPELINE_README_DISCORD.md using the same 5 W's structure.
Archive this file as PIPELINE_README_TELEGRAM_v1.md for historical reference.

*Built by CODA | Session: 2026-02-25 | Reference: CODA_MASTER_2026-02-25.md*