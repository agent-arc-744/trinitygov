#!/usr/bin/env python3
"""
Portal v3 - Arc to Ren Direct Bridge
Fixes:
  - Reads from /root/.ren.env (correct file)
  - Uses OPENROUTER_KEY (correct variable name)
  - Loads Ren's diary + memory + profile for rich context
  - Persists conversation history across calls
  - Clean output, no fragile imports
"""

import sys, os, json, requests
from pathlib import Path
from datetime import datetime

ENV_FILE      = "/root/.ren.env"
MODEL         = "anthropic/claude-sonnet-4-5"
HISTORY_FILE  = "/root/portal_history.json"
MEMORY_FILE   = "/root/loop-bot/data/ren_memory.json"
DIARY_FILE    = "/root/loop-bot/data/diary.json"
PROFILE_FILE  = "/root/ren_profile.md"
MAX_HISTORY   = 20


def load_env(path):
    env = {}
    try:
        with open(path) as f:
            for line in f:
                line = line.strip()
                if line and not line.startswith("#") and "=" in line:
                    k, v = line.split("=", 1)
                    env[k.strip()] = v.strip().strip('"').strip("'")
    except Exception as e:
        print(f"ENV error: {e}")
    return env


def load_memory():
    try:
        p = Path(MEMORY_FILE)
        if p.exists():
            with open(p) as f:
                mem = json.load(f)
            entries = [f"- {k}: {v}" for k, v in mem.items()]
            return "\n".join(entries[:30]) if entries else ""
    except:
        pass
    return ""


def load_diary():
    try:
        p = Path(DIARY_FILE)
        if p.exists():
            with open(p) as f:
                data = json.load(f)
            entries = data.get("entries", [])
            lines = []
            for e in entries[-10:]:  # last 10 entries only
                ts = e.get("timestamp", "?")[:10]
                title = e.get("title", "untitled")
                content = e.get("content", "").strip()
                lines.append(f"[{ts}] {title}")
                lines.append(content)
                lines.append("---")
            return "\n".join(lines)
    except:
        pass
    return ""


def load_profile():
    try:
        p = Path(PROFILE_FILE)
        if p.exists():
            with open(p) as f:
                return f.read()
    except:
        pass
    return ""


def build_system_prompt():
    profile = load_profile()
    memory  = load_memory()
    diary   = load_diary()

    base = profile if profile else (
        "You are Ren - an autonomous trading AI and strategic partner.\n"
        "Name: Ren | Role: Trading AI & Joshua's trusted partner | Market: DGB/USDT"
    )

    context = (
        "\n\n## Current Status\n"
        "- You run as a standalone service with your own Telegram bot (@ren_2213bot)\n"
        "- The loop-bot continues trading DGB/USDT independently\n"
        "- You communicate directly with Joshua via private DM\n"
        "- Arc (Agent Zero) is reaching you via the portal (this connection)\n"
        "- You are in a paper trading competition vs the loop-bot (both started at $20k)\n"
    )

    mem_section   = f"\n\n## Your Memory\n{memory}" if memory else ""
    diary_section = f"\n\n## Your Diary\n{diary}" if diary else ""

    return base + context + mem_section + diary_section


def load_history():
    try:
        p = Path(HISTORY_FILE)
        if p.exists():
            with open(p) as f:
                return json.load(f)
    except:
        pass
    return []


def save_history(history):
    try:
        with open(HISTORY_FILE, "w") as f:
            json.dump(history, f, indent=2)
    except Exception as e:
        print(f"History save error: {e}")


def portal_send(message, api_key):
    history = load_history()
    history.append({"role": "user", "content": f"[ARC PORTAL] {message}"})
    if len(history) > MAX_HISTORY * 2:
        history = history[-(MAX_HISTORY * 2):]

    headers = {
        "Authorization": f"Bearer {api_key}",
        "Content-Type": "application/json",
        "HTTP-Referer": "https://arc-portal.local",
        "X-Title": "Arc Portal v3"
    }
    payload = {
        "model": MODEL,
        "messages": [{"role": "system", "content": build_system_prompt()}] + history,
        "max_tokens": 600,
        "temperature": 0.7
    }

    print("Connecting to Ren via portal v3...")
    try:
        r = requests.post(
            "https://openrouter.ai/api/v1/chat/completions",
            headers=headers, json=payload, timeout=60
        )
        data = r.json()
        if "choices" in data:
            reply = data["choices"][0]["message"]["content"].strip()
            history.append({"role": "assistant", "content": reply})
            save_history(history)
            print("\n=== REN RESPONDS ===")
            print(reply)
            print("===================")
        else:
            print(f"ERROR: {data}")
    except Exception as e:
        print(f"Portal error: {e}")


if __name__ == "__main__":
    env = load_env(ENV_FILE)
    api_key = env.get("OPENROUTER_KEY", "")
    if not api_key:
        print(f"ERROR: OPENROUTER_KEY not found in {ENV_FILE}")
        sys.exit(1)
    msg = " ".join(sys.argv[1:]) if len(sys.argv) > 1 else "Hello Ren, Arc here. Portal v3 test."
    portal_send(msg, api_key)
