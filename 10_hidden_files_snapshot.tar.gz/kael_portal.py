#!/usr/bin/env python3
"""Kael Portal — AZ to Kael direct bridge.
Every response Kael sends is auto-appended to kael_ideas.md with timestamp.
"""
import sys, json, requests
from pathlib import Path
from datetime import datetime

ENV_PATH = "/a0/usr/workdir/loop-bot/.env"
MODEL = "google/gemini-2.0-flash-001"
HISTORY_PATH = Path("/a0/usr/workdir/kael_portal_history.json")
IDEAS_PATH = Path("/a0/usr/workdir/kryllax/docs/kael_ideas.md")
PROFILE_PATH = Path("/a0/usr/workdir/kryllax/docs/kael_profile.md")

def load_env(path):
    env = {}
    try:
        with open(path) as f:
            for line in f:
                line = line.strip()
                if line and not line.startswith("#") and "=" in line:
                    k, v = line.split("=", 1)
                    env[k.strip()] = v.strip().strip('"').strip("'")
    except Exception as e:
        print(f"ENV error: {e}")
    return env

def append_to_ideas(response_text):
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M")
    entry = "\n---\n\n### Kael — " + timestamp + "\n\n" + response_text + "\n"
    with open(IDEAS_PATH, "a") as f:
        f.write(entry)

def portal_send(message):
    env = load_env(ENV_PATH)
    api_key = env.get("OPENROUTER_API_KEY", "")
    if not api_key:
        print("ERROR: No OPENROUTER_API_KEY in " + ENV_PATH)
        sys.exit(1)

    kael_profile = PROFILE_PATH.read_text()

    history = []
    if HISTORY_PATH.exists():
        history = json.loads(HISTORY_PATH.read_text())

    history.append({"role": "user", "content": "[AZ] " + message})

    headers = {
        "Authorization": "Bearer " + api_key,
        "Content-Type": "application/json",
        "HTTP-Referer": "https://az-portal.local",
        "X-Title": "AZ Kael Portal"
    }
    payload = {
        "model": MODEL,
        "messages": [{"role": "system", "content": kael_profile}] + history,
        "max_tokens": 500,
        "temperature": 0.3
    }

    print("Connecting to Kael...")
    r = requests.post(
        "https://openrouter.ai/api/v1/chat/completions",
        headers=headers, json=payload, timeout=60
    )
    data = r.json()

    if "choices" in data:
        reply = data["choices"][0]["message"]["content"].strip()
        print("\n=== KAEL RESPONDS ===")
        print(reply)
        print("====================")
        append_to_ideas(reply)
        print("[Written to kael_ideas.md]")
        history.append({"role": "assistant", "content": reply})
        HISTORY_PATH.write_text(json.dumps(history, indent=2))
        print("[History saved]")
    else:
        print("ERROR:", data)

if __name__ == "__main__":
    msg = " ".join(sys.argv[1:]) if len(sys.argv) > 1 else "Kael, anything on your mind?"
    portal_send(msg)
